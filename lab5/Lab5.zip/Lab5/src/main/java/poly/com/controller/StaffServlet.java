package poly.com.controller;

import poly.com.model.Staff;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.beanutils.ConvertUtils;
import org.apache.commons.beanutils.converters.DateConverter;

import java.io.IOException;
import java.util.Date;

/**
 * Servlet cho Bài 1: dùng BeanUtils đọc toàn bộ dữ liệu form Staff.
 */
@WebServlet(urlPatterns = "/save")
public class StaffServlet extends HttpServlet {

    /** Đường dẫn JSP đặt dưới WEB-INF theo đúng mô hình MVC. */
    private static final String VIEW = "/WEB-INF/views/staff-form.jsp";

    /**
     * Hiển thị form khi người dùng truy cập lần đầu (HTTP GET).
     */
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.getRequestDispatcher(VIEW).forward(req, resp);
    }

    /**
     * Đọc form POST:
     * - Đăng ký DateConverter với pattern MM/dd/yyyy.
     * - BeanUtils.populate map toàn bộ parameter map vào Staff bean.
     * - Đặt Staff và thông báo để JSP render lại.
     */
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        Staff bean = new Staff();
        try {
            DateConverter converter = new DateConverter(new Date());
            converter.setPattern("MM/dd/yyyy");
            ConvertUtils.register(converter, Date.class);
            BeanUtils.populate(bean, req.getParameterMap());
            req.setAttribute("staff", bean);
            req.setAttribute("message", "Đọc dữ liệu biểu mẫu thành công.");
            req.setAttribute("alertType", "success");
        } catch (Exception e) {
            req.setAttribute("message", "Không thể đọc biểu mẫu: " + e.getMessage());
            req.setAttribute("alertType", "danger");
        }
        req.getRequestDispatcher(VIEW).forward(req, resp);
    }
}

