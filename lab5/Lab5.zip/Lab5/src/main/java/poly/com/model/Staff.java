package poly.com.model;

import java.util.Arrays;
import java.util.Date;

/**
 * JavaBean đại diện cho nhân viên nhập từ biểu mẫu Staff.
 * BeanUtils sẽ tự động map các field dựa vào tên thuộc tính.
 */
public class Staff {

    private String fullname;
    private Date birthday;
    private boolean gender;
    private String[] hobbies;
    private String country;
    private double salary;

    /**
     * Bắt buộc phải có constructor rỗng để BeanUtils có thể khởi tạo object.
     */
    public Staff() {
        // No-op
    }

    /**
     * @return Họ tên người dùng nhập.
     */
    public String getFullname() {
        return fullname;
    }

    /**
     * @param fullname cập nhật họ tên dựa vào trường input fullname.
     */
    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    /**
     * @return Ngày sinh đã được BeanUtils convert sang java.util.Date.
     */
    public Date getBirthday() {
        return birthday;
    }

    /**
     * @param birthday gán ngày sinh sau khi chuyển đổi theo định dạng MM/dd/yyyy.
     */
    public void setBirthday(Date birthday) {
        this.birthday = birthday;
    }

    /**
     * @return true nếu giới tính là Male, false nếu Female.
     */
    public boolean isGender() {
        return gender;
    }

    /**
     * @param gender biểu diễn kết quả từ radio button gender.
     */
    public void setGender(boolean gender) {
        this.gender = gender;
    }

    /**
     * @return Danh sách hobby lấy từ checkbox (BeanUtils tự map sang mảng).
     */
    public String[] getHobbies() {
        return hobbies;
    }

    /**
     * @param hobbies mảng giá trị hobby được chọn.
     */
    public void setHobbies(String[] hobbies) {
        this.hobbies = hobbies;
    }

    /**
     * @return Quốc gia được select trong dropdown.
     */
    public String getCountry() {
        return country;
    }

    /**
     * @param country mã quốc gia (VD: VN, US).
     */
    public void setCountry(String country) {
        this.country = country;
    }

    /**
     * @return Mức lương nhập từ input salary.
     */
    public double getSalary() {
        return salary;
    }

    /**
     * @param salary giá trị double đã parse từ input salary.
     */
    public void setSalary(double salary) {
        this.salary = salary;
    }

    @Override
    public String toString() {
        return "Staff{" +
                "fullname='" + fullname + '\'' +
                ", birthday=" + birthday +
                ", gender=" + gender +
                ", hobbies=" + Arrays.toString(hobbies) +
                ", country='" + country + '\'' +
                ", salary=" + salary +
                '}';
    }
}

