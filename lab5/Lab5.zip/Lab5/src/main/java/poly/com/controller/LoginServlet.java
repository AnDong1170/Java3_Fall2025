package poly.com.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import org.apache.commons.codec.binary.Base64;

import java.io.IOException;
import java.nio.charset.StandardCharsets;

/**
 * Servlet cho Bài 3: đăng nhập với Cookie (remember me) + Session.
 */
@WebServlet(urlPatterns = "/login")
public class LoginServlet extends HttpServlet {

    /** JSP chứa form đăng nhập. */
    private static final String VIEW = "/WEB-INF/views/login.jsp";

    /**
     * Đọc cookie user (Base64) khi tải trang.
     * Nếu tồn tại, giải mã username/password và đẩy lên request attribute.
     */
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Cookie[] cookies = req.getCookies();
        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if ("user".equals(cookie.getName())) {
                    String encoded = cookie.getValue();
                    byte[] decoded = Base64.decodeBase64(encoded);
                    String[] userInfo = new String(decoded, StandardCharsets.UTF_8).split(",", 2);
                    if (userInfo.length == 2) {
                        req.setAttribute("username", userInfo[0]);
                        req.setAttribute("password", userInfo[1]);
                        req.setAttribute("remembered", true);
                    }
                }
            }
        }
        req.getRequestDispatcher(VIEW).forward(req, resp);
    }

    /**
     * Xử lý POST:
     * - Kiểm tra thông tin đăng nhập tĩnh (FPT/poly).
     * - Lưu session username.
     * - Tuỳ checkbox Remember me để ghi cookie user hay xoá cookie cũ.
     */
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        String username = req.getParameter("username");
        String password = req.getParameter("password");
        boolean remember = req.getParameter("remember-me") != null;

        if ("admin".equalsIgnoreCase(username) && "123".equals(password)) {
            req.setAttribute("message", "Đăng nhập thành công!");
            req.setAttribute("alertType", "success");
            req.getSession().setAttribute("username", username);
            if (remember) {
                byte[] bytes = (username + "," + password).getBytes(StandardCharsets.UTF_8);
                String encoded = Base64.encodeBase64String(bytes);
                Cookie cookie = new Cookie("user", encoded);
                cookie.setMaxAge(30 * 24 * 60 * 60);
                cookie.setPath("/");
                resp.addCookie(cookie);
            } else {
                clearCookie(resp);
            }
        } else {
            req.setAttribute("message", "Sai tên đăng nhập hoặc mật khẩu!");
            req.setAttribute("alertType", "danger");
            clearCookie(resp);
        }

        req.setAttribute("username", username);
        req.setAttribute("password", password);
        req.setAttribute("remembered", remember);
        req.getRequestDispatcher(VIEW).forward(req, resp);
    }

    /**
     * Xoá cookie user bằng cách set MaxAge = 0 và path toàn app.
     */
    private void clearCookie(HttpServletResponse resp) {
        Cookie cookie = new Cookie("user", "");
        cookie.setMaxAge(0);
        cookie.setPath("/");
        resp.addCookie(cookie);
    }
}

