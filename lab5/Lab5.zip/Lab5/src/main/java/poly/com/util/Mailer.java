package poly.com.util;

import jakarta.activation.DataHandler;
import jakarta.mail.Authenticator;
import jakarta.mail.Message;
import jakarta.mail.MessagingException;
import jakarta.mail.PasswordAuthentication;
import jakarta.mail.Session;
import jakarta.mail.Transport;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeBodyPart;
import jakarta.mail.internet.MimeMessage;
import jakarta.mail.internet.MimeMultipart;
import jakarta.mail.util.ByteArrayDataSource;

import java.nio.charset.StandardCharsets;
import java.util.Properties;

/**
 * Tiện ích gửi mail dùng Jakarta Mail.
 * Cấu hình SMTP cố định cho Gmail và tài khoản được khai báo trực tiếp trong mã nguồn.
 * (Phù hợp cho bài lab, KHÔNG dùng cách này cho môi trường production.)
 */
public final class Mailer {

    /** Tài khoản Gmail dùng để gửi mail (phải khớp với app password bên dưới). */
    private static final String USERNAME = "donghtats02150@gmail.com";
    /** App password 16 ký tự (không chứa khoảng trắng). */
    private static final String APP_PASSWORD = "wgwrpouiemvbnlja";

    private Mailer() {
        // Utility class nên không cho khởi tạo.
    }

    /**
     * Thực hiện:
     * 1. Khởi tạo Session với Authenticator custom.
     * 2. Đóng gói MimeMessage với encoding UTF-8, body dạng HTML.
     * 3. Gửi mail thông qua Transport.
     */
    public static void send(String from, String to, String subject, String body, Attachment attachment) throws MessagingException {
        Session session = Session.getInstance(buildProps(), new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(USERNAME, APP_PASSWORD);
            }
        });

        MimeMessage mail = new MimeMessage(session);
        mail.setFrom(new InternetAddress(from));
        mail.setRecipients(Message.RecipientType.TO, to);
        mail.setSubject(subject, StandardCharsets.UTF_8.name());
        MimeBodyPart bodyPart = new MimeBodyPart();
        bodyPart.setContent(body, "text/html; charset=" + StandardCharsets.UTF_8);

        MimeMultipart multiPart = new MimeMultipart();
        multiPart.addBodyPart(bodyPart);

        if (attachment != null) {
            MimeBodyPart attachmentPart = new MimeBodyPart();
            attachmentPart.setDataHandler(new DataHandler(
                    new ByteArrayDataSource(attachment.bytes(), attachment.contentType())));
            attachmentPart.setFileName(attachment.fileName());
            multiPart.addBodyPart(attachmentPart);
        }

        mail.setContent(multiPart);
        mail.setReplyTo(mail.getFrom());
        Transport.send(mail);
    }

    /**
     * Khởi tạo Properties SMTP (AUTH + STARTTLS + host/port Gmail).
     */
    private static Properties buildProps() {
        Properties props = new Properties();
        props.setProperty("mail.smtp.auth", "true");
        props.setProperty("mail.smtp.starttls.enable", "true");
        props.setProperty("mail.smtp.host", "smtp.gmail.com");
        props.setProperty("mail.smtp.port", "587");
        return props;
    }

    public static String getConfiguredSender() {
        return USERNAME;
    }

    public record Attachment(String fileName, String contentType, byte[] bytes) {
    }
}

