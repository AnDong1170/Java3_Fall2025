package Lab3Servlet;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/bai4")
public class Bai4 extends HttpServlet
{
@Override
protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	// TODO Auto-generated method stub
	Map<String, Object> map = new HashMap<>();
	map.put("title", "Tiêu đề bản tin");
	map.put("content", "Nội dung bản tin thường rất dài");
	req.setAttribute("item", map);
	req.getRequestDispatcher("bai4.jsp").forward(req, resp);
}

}
