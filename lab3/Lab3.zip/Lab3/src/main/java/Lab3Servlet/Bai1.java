package Lab3Servlet;


import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Lab3.model.Country;
@WebServlet("/bai1")
public class Bai1 extends HttpServlet{

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		List<Country> list = List.of(
				new Country("VN", "Việt Nam"),
				new Country("US", "United States"),
				new Country("CN", "China")
				);
		req.setAttribute("Countries", list);
		req.getRequestDispatcher("/bai1.jsp").forward(req, resp);
	}

}
