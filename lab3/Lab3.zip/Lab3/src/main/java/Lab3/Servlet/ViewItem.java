package Lab3.Servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Lab3.model.ItemData;
import Lab3.model.ViewItemData;

@WebServlet("/viewitem")
public class ViewItem extends HttpServlet {
	@Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        processRequest(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        processRequest(req, resp);
    }
    
    private void processRequest(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String name = req.getParameter("id");

        ItemData selectedItem = ViewItemData.getItemByName(name);

        req.setAttribute("selectedItem", selectedItem);
        req.getRequestDispatcher("/detail.jsp").forward(req, resp);
    }

}
