package Lab3.Servlet;


import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import Lab3.model.ItemData;
import Lab3.model.ViewItemData;


@WebServlet("/bai5list")
public class Bai5 extends HttpServlet {
	 protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
			// req.setAttribute("lan", 10000000);

			/*
			 * ArrayList<String> danhsach = new ArrayList<String>(); danhsach.add("Cần");
			 * danhsach.add("Cù"); danhsach.add("Siêng"); danhsach.add("Năng");
			 * req.setAttribute("ds", danhsach);
			 */
			ArrayList<ItemData> items = ViewItemData.getItems();
			getServletContext().setAttribute("items", items);

			req.setAttribute("items", items);
			req.getRequestDispatcher("listproducts.jsp").forward(req, resp);
		    }
}