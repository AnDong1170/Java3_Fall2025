package Lab3.Servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Lab3.model.CartItem;
import Lab3.model.ItemData;
import Lab3.model.ViewItemData;
@WebServlet("/addtocart")
public class AddToCart extends HttpServlet{
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	    String name = req.getParameter("id");

	    // SỬA TẠI ĐÂY: dùng trực tiếp ViewItemData thay vì ServletContext
	    ItemData selected = ViewItemData.getItemByName(name);

	    if (selected == null) {
	        resp.sendRedirect(req.getContextPath() + "/bai5list");
	        return;
	    }

	    // Phần còn lại giữ nguyên
	    HttpSession session = req.getSession();
	    ArrayList<CartItem> cart = (ArrayList<CartItem>) session.getAttribute("cart");
	    if (cart == null) {
	        cart = new ArrayList<>();
	    }

	    boolean found = false;
	    for (CartItem ci : cart) {
	        if (ci.getItem().getName().equalsIgnoreCase(selected.getName())) {
	            ci.setQuantity(ci.getQuantity() + 1);
	            found = true;
	            break;
	        }
	    }
	    if (!found) {
	        cart.add(new CartItem(selected, 1));
	    }

	    session.setAttribute("cart", cart);
	    session.setAttribute("message", selected.getName() + " đã được thêm vào giỏ hàng!");

	    resp.sendRedirect(req.getContextPath() + "/bai5list");  // sửa luôn redirect cho chắc
	}


}
