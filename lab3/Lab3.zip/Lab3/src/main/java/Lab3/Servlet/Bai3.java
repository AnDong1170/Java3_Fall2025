package Lab3.Servlet;

import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/bai3")
public class Bai3 extends HttpServlet{
@Override
protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	// TODO Auto-generated method stub
	Map<String, Object> map = new HashMap<>();
	map.put("name", "iphone 2024");
	map.put("price", 12345.678);
	map.put("date", new Date());
	req.setAttribute("item", map);
	
	req.getRequestDispatcher("/bai3.jsp").forward(req, resp);
}
	

}
