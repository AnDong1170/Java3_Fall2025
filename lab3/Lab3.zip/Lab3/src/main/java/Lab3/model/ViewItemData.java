package Lab3.model;
import java.util.ArrayList;
import java.util.Date;

public class ViewItemData {
    private static ArrayList<ItemData> items;

    static {
        items = new ArrayList<>();
        items.add(new ItemData("iPhone 15", "iphone15.jpg", 23490000, 0.05, new Date()));
        items.add(new ItemData("Samsung Galaxy S24 Ultra", "s24ultra.jpg", 31990000, 0.1, new Date()));
        items.add(new ItemData("Xiaomi Redmi Note 13 Pro", "redmi13pro.jpg", 7990000, 0.15, new Date()));
        items.add(new ItemData("OnePlus 12", "oneplus12.jpg", 17990000, 0.08, new Date()));
        items.add(new ItemData("OPPO Reno 11", "reno11.jpg", 12490000, 0.12, new Date()));
        items.add(new ItemData("iPhone 17", "iphone17.jpg", 25990000, 0.05, new Date()));
    }

    public static ArrayList<ItemData> getItems() {
        return items;
    }

    public static ItemData getItemByName(String name) {
        for (ItemData item : items) {
            if (item.getName().equalsIgnoreCase(name)) {
                return item;
            }
        }
        return null;
    }
}