package Lab3.model;

public class CartItem {
    private ItemData item;
    private int quantity;

    public CartItem(ItemData item, int quantity) {
        this.item = item;
        this.quantity = quantity;
    }

    public ItemData getItem() { return item; }
    public void setItem(ItemData item) { this.item = item; }

    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }
}