# TÓM TẮT NỘI DUNG LAB8

## MỤC TIÊU BÀI HỌC
1. **Tổ chức Layout**: Xây dựng website với layout chung cho nhiều trang
2. **Xây dựng website đa ngôn ngữ**: Hỗ trợ Tiếng Việt và English

---

## PHẦN I: LAYOUT

### BÀI 1: THIẾT KẾ LAYOUT ĐƠN GIẢN

**Yêu cầu**: Xây dựng website gồm 3 trang (Home, About Us, Contact Us) có layout chung

**Cấu trúc**:
- **Header**: Tiêu đề "FPT POLYTECHNIC"
- **Navigation**: Menu điều hướng (Home, About Us, Contact Us)
- **Main Content**: Nội dung riêng của từng trang
- **Footer**: Thông tin bản quyền

**Cách hoạt động**:
1. `HomeServlet` xử lý 3 URL: `/home/index`, `/home/about`, `/home/contact`
2. Servlet xác định trang nào được yêu cầu dựa vào URI
3. Set attribute `view` chứa đường dẫn đến JSP tương ứng
4. Forward request đến `layout.jsp`
5. `layout.jsp` include trang JSP tương ứng vào phần main

---

## PHẦN II: I18N (INTERNATIONALIZATION)

### BÀI 3: XÂY DỰNG WEBSITE ĐA NGÔN NGỮ

**Yêu cầu**: Chuyển website ở Bài 1 thành website đa ngôn ngữ (Tiếng Việt/English)

**Cách hoạt động**:
1. **I18nFilter**: Lọc mọi request, kiểm tra tham số `lang` trong URL
   - Nếu có `?lang=vi` hoặc `?lang=en`, lưu vào session
2. **Resource Bundles**: 
   - `global_en.properties`, `global_vi.properties`: Chứa text cho menu (dùng chung)
   - `home_en.properties`, `home_vi.properties`: Chứa text cho nội dung trang
3. **JSP Pages**: Sử dụng JSTL `<fmt:message>` để hiển thị text theo ngôn ngữ
4. **Language Switcher**: 2 link "Tiếng Việt" và "English" để chuyển đổi ngôn ngữ

**Luồng xử lý**:
```
User click "English" → URL: ?lang=en 
→ I18nFilter lưu "en" vào session 
→ JSP đọc session.lang = "en" 
→ Load global_en.properties và home_en.properties 
→ Hiển thị text tiếng Anh
```

---

## CẤU TRÚC DỰ ÁN

```
Lab8/
├── src/main/
│   ├── java/poly/com/
│   │   ├── servlet/
│   │   │   └── HomeServlet.java      # Xử lý routing cho 3 trang
│   │   └── filter/
│   │       └── I18nFilter.java       # Xử lý đa ngôn ngữ
│   ├── resources/
│   │   ├── global_en.properties      # Menu tiếng Anh
│   │   ├── global_vi.properties      # Menu tiếng Việt
│   │   ├── home_en.properties        # Nội dung trang tiếng Anh
│   │   └── home_vi.properties        # Nội dung trang tiếng Việt
│   └── webapp/
│       ├── WEB-INF/
│       │   └── web.xml               # Cấu hình web app
│       └── views/
│           ├── layout.jsp            # Layout chung
│           └── home/
│               ├── index.jsp          # Trang chủ
│               ├── about.jsp          # Trang giới thiệu
│               └── contact.jsp        # Trang liên hệ
└── pom.xml                            # Cấu hình Maven
```

---

## CÁC THÀNH PHẦN CHÍNH

### 1. HomeServlet
- **Chức năng**: Điều hướng request đến đúng trang JSP
- **URL Pattern**: `/home/index`, `/home/about`, `/home/contact`
- **Cách hoạt động**: Kiểm tra URI → Set attribute `view` → Forward đến layout.jsp

### 2. I18nFilter
- **Chức năng**: Xử lý thay đổi ngôn ngữ
- **URL Pattern**: `/*` (áp dụng cho mọi request)
- **Cách hoạt động**: Đọc tham số `lang` → Lưu vào session

### 3. layout.jsp
- **Chức năng**: Template chung cho tất cả trang
- **Thành phần**: Header, Navigation, Main (include view), Footer
- **Đặc điểm**: Sử dụng JSTL để hiển thị text đa ngôn ngữ

### 4. Resource Bundles
- **global_*.properties**: Text dùng chung (menu)
- **home_*.properties**: Text riêng cho từng trang

---

## CÁCH SỬ DỤNG

1. **Build project**: `mvn clean install`
2. **Deploy lên Tomcat 10.1**
3. **Truy cập**: `http://localhost:8080/Lab8/home/index`
4. **Chuyển ngôn ngữ**: Click "Tiếng Việt" hoặc "English" trên menu

