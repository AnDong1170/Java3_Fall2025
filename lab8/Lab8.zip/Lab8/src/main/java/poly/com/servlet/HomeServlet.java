package poly.com.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * HomeServlet - Xử lý routing cho 3 trang: Home, About Us, Contact Us
 * 
 * Chức năng:
 * - Nhận request từ 3 URL: /home/index, /home/about, /home/contact
 * - Xác định trang nào được yêu cầu dựa vào URI
 * - Set attribute "view" chứa đường dẫn đến JSP tương ứng
 * - Forward request đến layout.jsp để hiển thị
 */
@WebServlet({ "/home/index", "/home/about", "/home/contact" })
public class HomeServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    /**
     * Phương thức service() được gọi khi có request đến servlet
     * 
     * @param req  - HttpServletRequest chứa thông tin request
     * @param resp - HttpServletResponse để gửi response
     */
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        
        // Lấy URI của request (ví dụ: /Lab8/home/index)
        String uri = req.getRequestURI();
        
        // Kiểm tra URI để xác định trang nào được yêu cầu
        // và set attribute "view" chứa đường dẫn đến JSP tương ứng
        
        if (uri.contains("index")) {
            // Nếu URI chứa "index" → Trang chủ
            req.setAttribute("view", "/views/home/index.jsp");
        } else if (uri.contains("about")) {
            // Nếu URI chứa "about" → Trang giới thiệu
            req.setAttribute("view", "/views/home/about.jsp");
        } else if (uri.contains("contact")) {
            // Nếu URI chứa "contact" → Trang liên hệ
            req.setAttribute("view", "/views/home/contact.jsp");
        }
        
        // Forward request đến layout.jsp
        // layout.jsp sẽ include trang JSP được chỉ định trong attribute "view"
        req.getRequestDispatcher("/views/layout.jsp").forward(req, resp);
    }
}

