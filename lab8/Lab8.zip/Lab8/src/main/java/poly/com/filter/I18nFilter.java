package poly.com.filter;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * I18nFilter - Filter xử lý đa ngôn ngữ (Internationalization)
 * 
 * Chức năng:
 * - Lọc mọi request đến website
 * - Kiểm tra tham số "lang" trong URL (ví dụ: ?lang=vi hoặc ?lang=en)
 * - Nếu có tham số lang, lưu vào session để các trang JSP sử dụng
 * - Cho phép chuyển đổi ngôn ngữ động mà không cần reload trang
 * 
 * Cách hoạt động:
 * - User click "Tiếng Việt" → URL: ?lang=vi → Filter lưu "vi" vào session
 * - User click "English" → URL: ?lang=en → Filter lưu "en" vào session
 * - Các trang JSP sẽ đọc session.lang để hiển thị text đúng ngôn ngữ
 */
@WebFilter("/*")  // Áp dụng cho mọi request (/*)
public class I18nFilter extends HttpFilter {
    private static final long serialVersionUID = 1L;

    /**
     * Phương thức doFilter() được gọi trước khi request đến servlet
     * 
     * @param req    - HttpServletRequest chứa thông tin request
     * @param resp   - HttpServletResponse để gửi response
     * @param chain  - FilterChain để chuyển request đến filter/servlet tiếp theo
     */
    @Override
    public void doFilter(HttpServletRequest req, HttpServletResponse resp, FilterChain chain)
            throws IOException, ServletException {
        
        // Lấy tham số "lang" từ URL (ví dụ: ?lang=vi hoặc ?lang=en)
        String lang = req.getParameter("lang");
        
        // Nếu có tham số lang, lưu vào session
        // Session sẽ được giữ trong suốt phiên làm việc của user
        if (lang != null) {
            req.getSession().setAttribute("lang", lang);
        }
        
        // Chuyển request đến filter/servlet tiếp theo trong chain
        // Nếu không có filter nào khác, request sẽ đến servlet
        chain.doFilter(req, resp);
    }
}

