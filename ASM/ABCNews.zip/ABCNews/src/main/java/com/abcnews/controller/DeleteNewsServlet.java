package com.abcnews.controller;

import com.abcnews.dao.NewsDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/delete-news")
public class DeleteNewsServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String id = request.getParameter("id");
        
        // Gọi DAO để xóa
        NewsDAO dao = new NewsDAO();
        dao.deleteNews(id);
        
        // Xóa xong thì quay lại trang quản lý
        // Cần kiểm tra session để biết quay về đường dẫn admin hay reporter, 
        // nhưng servlet NewsManagerServlet đã map cả 2 nên ta gọi 1 cái là được.
        response.sendRedirect("admin/news");
    }
}