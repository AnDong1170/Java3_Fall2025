package com.abcnews.controller;

import com.abcnews.dao.CategoryDAO;
import com.abcnews.model.Category;
import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletContextEvent;
import jakarta.servlet.ServletContextListener;
import jakarta.servlet.annotation.WebListener;
import java.util.List;

@WebListener // Annotation này giúp Tomcat nhận diện đây là class chạy ngầm
public class AppListener implements ServletContextListener {

    @Override
    public void contextInitialized(ServletContextEvent sce) {
        // Code này chạy 1 lần duy nhất khi website khởi động
        ServletContext application = sce.getServletContext();
        
        CategoryDAO dao = new CategoryDAO();
        List<Category> list = dao.getAllCategories();
        
        // Lưu list vào biến toàn cục tên là "globalCategories"
        application.setAttribute("globalCategories", list);
    }

    @Override
    public void contextDestroyed(ServletContextEvent sce) {
        // Chạy khi tắt server (không cần làm gì)
    }
}