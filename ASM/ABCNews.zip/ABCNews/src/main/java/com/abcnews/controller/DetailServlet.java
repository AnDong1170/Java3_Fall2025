package com.abcnews.controller;

import com.abcnews.dao.NewsDAO;
import com.abcnews.model.News;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/detail")
public class DetailServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String id = request.getParameter("id"); 
        NewsDAO dao = new NewsDAO();
        
        News n = dao.getNewsById(id);
        
        if(n != null) {
            // 1. Lấy tin cùng loại (cho phần dưới bài viết)
            List<News> related = dao.getRelatedNews(n.getCategoryId(), n.getId());
            
            // --- BẮT ĐẦU: THÊM ĐOẠN NÀY CHO SIDEBAR ---
            // 2. Lấy Top tin xem nhiều (cho phần "Có thể bạn quan tâm" bên phải)
            List<News> topNews = dao.getTopNews(); 
            request.setAttribute("topNews", topNews);
            // --- KẾT THÚC: ĐOẠN CẦN THÊM ---
            
            request.setAttribute("news", n);
            request.setAttribute("relatedNews", related);
            
            request.getRequestDispatcher("/views/detail.jsp").forward(request, response);
        } else {
            response.sendRedirect("home"); 
        }
    }
}