package com.abcnews.utils;

import jakarta.mail.Authenticator;
import jakarta.mail.Message;
import jakarta.mail.PasswordAuthentication;
import jakarta.mail.Session;
import jakarta.mail.Transport;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeMessage;
import java.util.Properties;

public class EmailService {
    // Cấu hình thông tin Email gửi đi
    private static final String FROM_EMAIL = "donghtats02150@gmail.com"; 
    // Mật khẩu ứng dụng (đã xóa khoảng trắng)
    private static final String APP_PASSWORD = "ognmwmiyfuwycpmh";

    public static void send(String to, String subject, String body) {
        // 1. Cấu hình SMTP Gmail
        Properties props = new Properties();
        props.put("mail.smtp.host", "smtp.gmail.com"); 
        props.put("mail.smtp.port", "587"); 
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true"); 

        // 2. Tạo phiên làm việc (Session) với xác thực
        Authenticator auth = new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                // SỬA LỖI: Dùng đúng tên biến APP_PASSWORD
                return new PasswordAuthentication(FROM_EMAIL, APP_PASSWORD);
            }
        };
        Session session = Session.getInstance(props, auth);

        // 3. Tạo tin nhắn và gửi
        try {
            MimeMessage msg = new MimeMessage(session);
            
            // Người gửi, người nhận
            msg.setFrom(new InternetAddress(FROM_EMAIL, "ABC News System"));
            msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to));
            
            // Tiêu đề
            msg.setSubject(subject, "UTF-8");
            
            // Nội dung (HTML)
            msg.setContent(body, "text/html; charset=UTF-8");

            // Gửi đi
            Transport.send(msg);
            System.out.println("Gửi email thành công đến: " + to);
            
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Gửi email thất bại đến: " + to);
        }
    }
}