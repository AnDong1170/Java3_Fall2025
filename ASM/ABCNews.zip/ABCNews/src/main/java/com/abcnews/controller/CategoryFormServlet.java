package com.abcnews.controller;

import com.abcnews.dao.CategoryDAO;
import com.abcnews.model.Category;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List; // Nhớ import List

@WebServlet("/category-form")
public class CategoryFormServlet extends HttpServlet {
    
    // Mở form
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String id = request.getParameter("id");
        if (id != null) {
            CategoryDAO dao = new CategoryDAO();
            Category c = dao.getCategoryById(id);
            request.setAttribute("category", c);
            request.setAttribute("isEdit", true);
        }
        request.getRequestDispatcher("/views/admin/category-form.jsp").forward(request, response);
    }

    // Lưu dữ liệu
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        String id = request.getParameter("id");
        String name = request.getParameter("name");
        
        Category c = new Category(id, name);
        CategoryDAO dao = new CategoryDAO();
        
        // 1. Lưu vào Database (Insert hoặc Update)
        if (dao.getCategoryById(id) != null) {
            dao.updateCategory(c);
        } else {
            dao.insertCategory(c);
        }
        
        // --- ĐOẠN CODE QUAN TRỌNG VỪA THÊM VÀO ---
        // Mục đích: Cập nhật lại menu trên Header ngay lập tức
        List<Category> list = dao.getAllCategories();
        request.getServletContext().setAttribute("globalCategories", list);
        // ------------------------------------------
        
        // Chuyển hướng về trang danh sách
        response.sendRedirect("admin/categories");
    }
}