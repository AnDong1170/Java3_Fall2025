package com.abcnews.controller;

import com.abcnews.dao.NewsDAO;
import com.abcnews.model.News;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/category")
public class CategoryServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String cid = request.getParameter("cid"); // Lấy mã loại tin (VD: category?cid=TT)
        NewsDAO dao = new NewsDAO();
        
        List<News> list = dao.getNewsByCategory(cid);
        
        request.setAttribute("listNews", list);
        // Tái sử dụng giao diện home.jsp nhưng hiển thị list đã lọc
        request.getRequestDispatcher("/views/home.jsp").forward(request, response);
    }
}