package com.abcnews.controller;

import com.abcnews.dao.NewsletterDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/newsletter")
public class NewsletterServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
        // 1. Quan trọng: Xử lý tiếng Việt (nếu có)
        request.setCharacterEncoding("UTF-8");
        
        // 2. Lấy dữ liệu
        String email = request.getParameter("email");
        String referer = request.getHeader("Referer"); // Trang trước đó
        
        HttpSession session = request.getSession();
        
        if (email != null && !email.trim().isEmpty()) {
            NewsletterDAO dao = new NewsletterDAO();
            
            // --- SỬA GỌN LẠI ---
            // Gọi hàm insert, nó sẽ trả về True (thành công) hoặc False (trùng/lỗi)
            boolean isSuccess = dao.insert(email);
            
            if (isSuccess) {
                session.setAttribute("message", "Đăng ký nhận tin thành công!");
            } else {
                // Nếu False => Tức là email đã tồn tại trong DB
                session.setAttribute("error", "Email này đã được đăng ký rồi!");
            }
            // -------------------
            
        } else {
            session.setAttribute("error", "Vui lòng nhập đúng định dạng email.");
        }
        
        // 3. Chuyển hướng quay lại trang cũ
        if (referer != null) {
            response.sendRedirect(referer);
        } else {
            response.sendRedirect(request.getContextPath() + "/home");
        }
    }
}