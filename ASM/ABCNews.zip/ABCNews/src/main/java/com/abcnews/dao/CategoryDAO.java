package com.abcnews.dao;

import com.abcnews.model.Category; // Bạn nhớ tạo class Category model tương ứng nhé (Id, Name)
import com.abcnews.utils.Jdbc;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class CategoryDAO {
    // Tạo class inner hoặc file riêng cho Category Model. 
    // Để nhanh tôi giả sử bạn đã có class Category(String id, String name) trong package model.
    // Nếu chưa có, bạn tạo class Category trong package model giống class User/News nhé.

    public List<Category> getAllCategories() {
        List<Category> list = new ArrayList<>();
        String query = "SELECT * FROM Categories";
        try {
            Connection conn = new Jdbc().getConnection();
            PreparedStatement ps = conn.prepareStatement(query);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                // Giả sử class Category có constructor (id, name)
                list.add(new Category(rs.getString("Id"), rs.getString("Name")));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
    
 // Lấy loại tin theo ID (dùng cho chức năng Sửa)
    public Category getCategoryById(String id) {
        String query = "SELECT * FROM Categories WHERE Id = ?";
        try {
            Connection conn = new Jdbc().getConnection();
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return new Category(rs.getString("Id"), rs.getString("Name"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    // Thêm mới
    public void insertCategory(Category c) {
        String query = "INSERT INTO Categories (Id, Name) VALUES (?, ?)";
        try {
            Connection conn = new Jdbc().getConnection();
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(1, c.getId());
            ps.setString(2, c.getName());
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Cập nhật
    public void updateCategory(Category c) {
        String query = "UPDATE Categories SET Name = ? WHERE Id = ?";
        try {
            Connection conn = new Jdbc().getConnection();
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(1, c.getName());
            ps.setString(2, c.getId());
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Xóa
    public void deleteCategory(String id) {
        // Lưu ý: Nếu loại tin này đã có bài viết, SQL sẽ báo lỗi ràng buộc khóa ngoại.
        // Cần xóa bài viết trước hoặc xử lý try-catch kỹ. Ở đây làm đơn giản trước.
        String query = "DELETE FROM Categories WHERE Id = ?";
        try {
            Connection conn = new Jdbc().getConnection();
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(1, id);
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}