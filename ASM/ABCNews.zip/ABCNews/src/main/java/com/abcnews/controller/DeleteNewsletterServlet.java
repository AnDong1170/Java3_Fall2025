package com.abcnews.controller;

import com.abcnews.dao.NewsletterDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/delete-newsletter")
public class DeleteNewsletterServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String email = request.getParameter("email");
        NewsletterDAO dao = new NewsletterDAO();
        dao.delete(email);
        response.sendRedirect("admin/newsletters");
    }
}