package com.abcnews.controller;

import com.abcnews.dao.CategoryDAO;
import com.abcnews.dao.NewsDAO;
import com.abcnews.dao.NewsletterDAO;
import com.abcnews.model.Category;
import com.abcnews.model.News;
import com.abcnews.model.User;
import com.abcnews.utils.EmailService;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.http.Part;
import java.io.File;
import java.io.IOException;
import java.util.List;

@WebServlet("/admin/news-form")
@MultipartConfig(
    fileSizeThreshold = 1024 * 1024 * 2, // 2MB
    maxFileSize = 1024 * 1024 * 10,      // 10MB
    maxRequestSize = 1024 * 1024 * 50    // 50MB
)
public class NewsFormServlet extends HttpServlet {
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String id = request.getParameter("id");
        
        CategoryDAO cateDao = new CategoryDAO();
        List<Category> listCate = cateDao.getAllCategories();
        request.setAttribute("categories", listCate);

        if (id != null && !id.isEmpty()) {
            NewsDAO newsDao = new NewsDAO();
            News news = newsDao.getNewsById(id);
            request.setAttribute("news", news);
            request.setAttribute("isEdit", true);
        }
        
        request.getRequestDispatcher("/views/admin/news-form.jsp").forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        
        // 1. Lấy dữ liệu Text
        String id = request.getParameter("id");
        String title = request.getParameter("title");
        String content = request.getParameter("content");
        String categoryId = request.getParameter("categoryId");
        boolean home = request.getParameter("home") != null;
        
        // Lấy cờ báo hiệu xem đây là Sửa hay Thêm mới (Cần thêm input hidden này bên JSP)
        boolean isEditMode = "true".equals(request.getParameter("isEditMode"));
        
        // 2. Xử lý Upload Ảnh
        String imagePath = null;
        try {
            Part filePart = request.getPart("imageFile");
            String fileName = filePart.getSubmittedFileName();
            
            if (fileName != null && !fileName.isEmpty()) {
                String realPath = request.getServletContext().getRealPath("/uploads");
                File uploadDir = new File(realPath);
                if (!uploadDir.exists()) uploadDir.mkdir();
                
                String uniqueFileName = System.currentTimeMillis() + "_" + fileName;
                filePart.write(realPath + File.separator + uniqueFileName);
                imagePath = "uploads/" + uniqueFileName; 
            } 
        } catch (Exception e) {
            e.printStackTrace();
        }

        if (imagePath == null) {
            imagePath = request.getParameter("currentImage");
        }

        // 3. Lấy User đang đăng nhập
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("account");
        String authorId = (user != null) ? user.getId() : "admin";
        
        // Tạo đối tượng News (Để giữ lại dữ liệu nếu bị lỗi)
        News n = new News();
        n.setId(id);
        n.setTitle(title);
        n.setContent(content);
        n.setImage(imagePath);
        n.setCategoryId(categoryId);
        n.setHome(home);
        n.setAuthorId(authorId);

        NewsDAO dao = new NewsDAO();
        
        // --- 4. KIỂM TRA TRÙNG ID (Logic mới thêm) ---
        // Chỉ kiểm tra khi đang THÊM MỚI (!isEditMode)
        if (!isEditMode) {
            News existNews = dao.getNewsById(id);
            if (existNews != null) {
                // A. Báo lỗi: ID đã tồn tại
                request.setAttribute("errorId", "Mã tin '" + id + "' đã tồn tại! Vui lòng nhập mã khác.");
                
                // B. Giữ lại dữ liệu cũ (để form không bị trắng)
                request.setAttribute("news", n);
                request.setAttribute("isEdit", false);
                
                // C. Load lại danh mục (quan trọng)
                CategoryDAO cateDao = new CategoryDAO();
                request.setAttribute("categories", cateDao.getAllCategories());

                // D. Quay lại trang JSP
                request.getRequestDispatcher("/views/admin/news-form.jsp").forward(request, response);
                return; // DỪNG CODE, KHÔNG CHẠY TIẾP
            }
        }
        
        // --- 5. Xử lý Lưu vào Database ---
        if (isEditMode) {
            // Trường hợp Update: Chỉ lưu, KHÔNG gửi mail
            dao.updateNews(n);
        } else {
            // Trường hợp Insert: Lưu xong thì GỬI EMAIL
            dao.insertNews(n);
            
            // --- GỬI EMAIL TỰ ĐỘNG ---
            final String mailTitle = title;
            final String mailContent = content;
            new Thread(() -> {
                try {
                    NewsletterDAO newsletterDAO = new NewsletterDAO();
                    List<String> emails = newsletterDAO.getAllEmails();
                    
                    String subject = "ABC News: Bài viết mới - " + mailTitle;
                    String body = "<div style='font-family: Arial; padding: 20px; border: 1px solid #ddd;'>"
                                + "<h2 style='color: #FF69B4;'>ABC News thông báo tin mới!</h2>"
                                + "<h3>" + mailTitle + "</h3>"
                                + "<p>" + (mailContent.length() > 200 ? mailContent.substring(0, 200) + "..." : mailContent) + "</p>"
                                + "<br>"
                                + "<a href='http://localhost:8080/ABCNews/detail?id=" + id + "' style='background-color: #FF69B4; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>Xem chi tiết</a>"
                                + "</div>";

                    for (String email : emails) {
                        EmailService.send(email, subject, body);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }).start();
        }
        
        response.sendRedirect("news");
    }
}