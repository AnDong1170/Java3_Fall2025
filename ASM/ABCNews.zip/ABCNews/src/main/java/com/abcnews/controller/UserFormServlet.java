package com.abcnews.controller;

import com.abcnews.dao.UserDAO;
import com.abcnews.model.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Date;

@WebServlet("/admin/user-form")
public class UserFormServlet extends HttpServlet {
    
    // Mở form
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String id = request.getParameter("id");
        if (id != null) {
            UserDAO dao = new UserDAO();
            User u = dao.getUserById(id);
            request.setAttribute("user", u);
            request.setAttribute("isEdit", true);
        }
        request.getRequestDispatcher("/views/admin/user-form.jsp").forward(request, response);
    }

    // Lưu
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        
        String id = request.getParameter("id");
        String password = request.getParameter("password");
        String fullname = request.getParameter("fullname");
        String email = request.getParameter("email");
        String mobile = request.getParameter("mobile");
        boolean gender = Boolean.parseBoolean(request.getParameter("gender"));
        boolean role = Boolean.parseBoolean(request.getParameter("role"));
        
        // Xử lý ngày sinh (nếu rỗng thì để null hoặc ngày hiện tại)
        String birthdayStr = request.getParameter("birthday");
        Date birthday = (birthdayStr != null && !birthdayStr.isEmpty()) ? Date.valueOf(birthdayStr) : null;

        User u = new User(id, password, fullname, birthday, gender, mobile, email, role);
        UserDAO dao = new UserDAO();

        if (dao.getUserById(id) != null) {
            dao.updateUser(u);
        } else {
            dao.insertUser(u);
        }
        response.sendRedirect("users");
    }
}