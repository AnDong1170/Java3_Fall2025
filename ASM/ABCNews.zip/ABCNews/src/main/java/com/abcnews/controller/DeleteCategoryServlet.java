package com.abcnews.controller;

import com.abcnews.dao.CategoryDAO;
import com.abcnews.model.Category;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List; // Nhớ import List

@WebServlet("/delete-category")
public class DeleteCategoryServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String id = request.getParameter("id");
        CategoryDAO dao = new CategoryDAO();
        
        // 1. Xóa trong Database
        dao.deleteCategory(id);
        
        // --- THÊM ĐOẠN NÀY ĐỂ CẬP NHẬT HEADER ---
        // Lấy lại danh sách mới nhất sau khi xóa
        List<Category> list = dao.getAllCategories();
        // Ghi đè vào biến toàn cục "globalCategories"
        request.getServletContext().setAttribute("globalCategories", list);
        // ----------------------------------------
        
        response.sendRedirect("admin/categories");
    }
}