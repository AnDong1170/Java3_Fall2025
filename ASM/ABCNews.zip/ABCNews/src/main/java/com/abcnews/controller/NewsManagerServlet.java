package com.abcnews.controller;

import com.abcnews.dao.NewsDAO;
import com.abcnews.model.News;
import com.abcnews.model.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

// Map cả 2 đường dẫn cho Admin và Phóng viên
@WebServlet({"/admin/news", "/reporter/news"})
public class NewsManagerServlet extends HttpServlet {
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // 1. Thiết lập tiếng Việt
    	request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html; charset=UTF-8");

        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("account");

        // 2. Kiểm tra đăng nhập
        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        NewsDAO dao = new NewsDAO();
        List<News> list;

        // 3. Phân quyền dữ liệu
        if (user.isRole()) { 
            // Nếu là Admin (Role = true): Lấy tất cả tin
            list = dao.getAllNews();
        } else {
            // Nếu là Phóng viên (Role = false): Chỉ lấy tin của chính mình
            list = dao.getNewsByAuthor(user.getId());
        }

        request.setAttribute("listNews", list);
        request.getRequestDispatcher("/views/admin/news-list.jsp").forward(request, response);
    }
}