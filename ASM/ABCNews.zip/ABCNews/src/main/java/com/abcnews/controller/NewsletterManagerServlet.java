package com.abcnews.controller;

import com.abcnews.dao.NewsletterDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/admin/newsletters")
public class NewsletterManagerServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        NewsletterDAO dao = new NewsletterDAO();
        // Sử dụng lại hàm getAllEmails() bạn đã có để lấy danh sách
        request.setAttribute("emails", dao.getAllEmails());
        request.getRequestDispatcher("/views/admin/newsletter-list.jsp").forward(request, response);
    }
}