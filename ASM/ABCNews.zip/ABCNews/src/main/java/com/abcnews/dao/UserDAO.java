package com.abcnews.dao;

import com.abcnews.model.User;
import com.abcnews.utils.Jdbc;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class UserDAO {
    Connection conn = null;
    PreparedStatement ps = null;
    ResultSet rs = null;

    // 1. Kiểm tra đăng nhập (Giữ nguyên cái cũ)
    public User checkLogin(String username, String password) {
        try {
            String query = "SELECT * FROM Users WHERE Id = ? AND Password = ?";
            conn = new Jdbc().getConnection();
            ps = conn.prepareStatement(query);
            ps.setString(1, username);
            ps.setString(2, password);
            rs = ps.executeQuery();
            if (rs.next()) {
                return new User(
                    rs.getString("Id"), rs.getString("Password"), rs.getString("Fullname"),
                    rs.getDate("Birthday"), rs.getBoolean("Gender"), rs.getString("Mobile"),
                    rs.getString("Email"), rs.getBoolean("Role")
                );
            }
        } catch (Exception e) { e.printStackTrace(); }
        return null;
    }

    // 2. Lấy tất cả người dùng
    public List<User> getAllUsers() {
        List<User> list = new ArrayList<>();
        String query = "SELECT * FROM Users";
        try {
            conn = new Jdbc().getConnection();
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new User(
                    rs.getString("Id"), rs.getString("Password"), rs.getString("Fullname"),
                    rs.getDate("Birthday"), rs.getBoolean("Gender"), rs.getString("Mobile"),
                    rs.getString("Email"), rs.getBoolean("Role")
                ));
            }
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }

    // 3. Lấy theo ID (để sửa)
    public User getUserById(String id) {
        String query = "SELECT * FROM Users WHERE Id = ?";
        try {
            conn = new Jdbc().getConnection();
            ps = conn.prepareStatement(query);
            ps.setString(1, id);
            rs = ps.executeQuery();
            if (rs.next()) {
                return new User(
                    rs.getString("Id"), rs.getString("Password"), rs.getString("Fullname"),
                    rs.getDate("Birthday"), rs.getBoolean("Gender"), rs.getString("Mobile"),
                    rs.getString("Email"), rs.getBoolean("Role")
                );
            }
        } catch (Exception e) { e.printStackTrace(); }
        return null;
    }

    // 4. Thêm mới
    public void insertUser(User u) {
        String query = "INSERT INTO Users (Id, Password, Fullname, Birthday, Gender, Mobile, Email, Role) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try {
            conn = new Jdbc().getConnection();
            ps = conn.prepareStatement(query);
            ps.setString(1, u.getId());
            ps.setString(2, u.getPassword());
            ps.setString(3, u.getFullname());
            ps.setDate(4, u.getBirthday());
            ps.setBoolean(5, u.isGender());
            ps.setString(6, u.getMobile());
            ps.setString(7, u.getEmail());
            ps.setBoolean(8, u.isRole());
            ps.executeUpdate();
        } catch (Exception e) { e.printStackTrace(); }
    }

    // 5. Cập nhật
    public void updateUser(User u) {
        String query = "UPDATE Users SET Password=?, Fullname=?, Birthday=?, Gender=?, Mobile=?, Email=?, Role=? WHERE Id=?";
        try {
            conn = new Jdbc().getConnection();
            ps = conn.prepareStatement(query);
            ps.setString(1, u.getPassword());
            ps.setString(2, u.getFullname());
            ps.setDate(3, u.getBirthday());
            ps.setBoolean(4, u.isGender());
            ps.setString(5, u.getMobile());
            ps.setString(6, u.getEmail());
            ps.setBoolean(7, u.isRole());
            ps.setString(8, u.getId());
            ps.executeUpdate();
        } catch (Exception e) { e.printStackTrace(); }
    }

    // 6. Xóa
    public void deleteUser(String id) {
        String query = "DELETE FROM Users WHERE Id = ?";
        try {
            conn = new Jdbc().getConnection();
            ps = conn.prepareStatement(query);
            ps.setString(1, id);
            ps.executeUpdate();
        } catch (Exception e) { e.printStackTrace(); }
    }
}