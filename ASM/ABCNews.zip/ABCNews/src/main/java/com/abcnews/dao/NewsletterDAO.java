package com.abcnews.dao;

import com.abcnews.utils.Jdbc; 
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class NewsletterDAO {
    
    // 1. Thêm email mới (Đăng ký nhận tin)
    public boolean insert(String email) {
        String query = "INSERT INTO Newsletters (Email, Enabled) VALUES (?, 1)";
        try {
            Connection conn = new Jdbc().getConnection();
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(1, email);
            ps.executeUpdate();
            
            // Đóng kết nối để giải phóng tài nguyên
            conn.close();
            
            return true; // Thêm thành công
        } catch (Exception e) {
            // Nếu trùng email (Lỗi Primary Key), code sẽ nhảy vào đây
            // Mình đã tắt in lỗi để Console không hiện chữ đỏ, vì lỗi này mình đã dự tính trước
            // e.printStackTrace(); 
            return false; // Trả về false để Servlet báo lỗi "Email đã tồn tại"
        }
    }

    // 2. Lấy danh sách email (Dùng để gửi mail hàng loạt)
    public List<String> getAllEmails() {
        List<String> list = new ArrayList<>();
        String query = "SELECT Email FROM Newsletters WHERE Enabled = 1";
        try {
            Connection conn = new Jdbc().getConnection();
            PreparedStatement ps = conn.prepareStatement(query);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(rs.getString("Email"));
            }
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
    
    // 3. Xóa email (Dùng cho trang quản lý Newsletter)
    public void delete(String email) {
        String query = "DELETE FROM Newsletters WHERE Email = ?";
        try {
            Connection conn = new Jdbc().getConnection();
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(1, email);
            ps.executeUpdate();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}