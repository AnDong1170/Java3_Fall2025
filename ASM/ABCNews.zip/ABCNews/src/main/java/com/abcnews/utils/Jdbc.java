package com.abcnews.utils;

import java.sql.Connection;
import java.sql.DriverManager;

public class Jdbc{
    public Connection getConnection() throws Exception {
        String url = "jdbc:sqlserver://localhost:1433;databaseName=ABCNews;encrypt=true;trustServerCertificate=true";
        String user = "sa"; // Thay user của bạn
        String password = "123456"; // Thay pass của bạn
        Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
        return DriverManager.getConnection(url, user, password);
    }
}