package com.abcnews.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import com.abcnews.dao.NewsDAO;
import com.abcnews.model.News;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "SearchControl", urlPatterns = {"/search"})
public class SearchControl extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        response.setContentType("text/html;charset=UTF-8");
        request.setCharacterEncoding("UTF-8"); 
        
        // 1. Lấy từ khóa
        String txtSearch = request.getParameter("txt");
        
        // 2. Gọi DAO
        NewsDAO dao = new NewsDAO();
        
        // --- SỬA Ở ĐÂY: Đổi thành searchByName cho khớp với DAO ---
        List<News> list = dao.searchByName(txtSearch);
        
        // 3. Đẩy dữ liệu về
        request.setAttribute("listNews", list);
        request.setAttribute("txtS", txtSearch);
        
        // Thông báo kết quả (Logic hiển thị đẹp)
        if (list == null || list.isEmpty()) {
             request.setAttribute("error", "Không tìm thấy bài viết nào cho từ khóa: " + txtSearch);
        } else {
             request.setAttribute("message", "Tìm thấy " + list.size() + " kết quả.");
        }
        
        // 4. Chuyển trang
        request.getRequestDispatcher("/views/home.jsp").forward(request, response);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }
}