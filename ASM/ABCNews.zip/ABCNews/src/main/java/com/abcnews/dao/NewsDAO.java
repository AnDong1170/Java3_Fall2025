package com.abcnews.dao;

import com.abcnews.model.News;
import com.abcnews.utils.Jdbc;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class NewsDAO {
    Connection conn = null;
    PreparedStatement ps = null;
    ResultSet rs = null;

    public List<News> getHomeNews() {
        List<News> list = new ArrayList<>();
        String query = "SELECT * FROM News WHERE Home = 1 ORDER BY PostedDate DESC";
        try {
            conn = new Jdbc().getConnection();
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new News(
                    rs.getString("Id"),
                    rs.getString("Title"),
                    rs.getString("Content"),
                    rs.getString("Image"),
                    rs.getDate("PostedDate"),
                    rs.getString("Author"),
                    rs.getInt("ViewCount"),
                    rs.getString("CategoryId"),
                    rs.getBoolean("Home")
                ));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
    
 // Lấy tin tức chi tiết theo ID
    public News getNewsById(String id) {
        String query = "SELECT * FROM News WHERE Id = ?";
        try {
            conn = new Jdbc().getConnection();
            ps = conn.prepareStatement(query);
            ps.setString(1, id);
            rs = ps.executeQuery();
            if (rs.next()) {
                // Tăng lượt xem mỗi khi đọc chi tiết (Yêu cầu Assignment: Tăng số lượt xem [cite: 139])
                increaseViewCount(id); 
                
                return new News(
                    rs.getString("Id"),
                    rs.getString("Title"),
                    rs.getString("Content"),
                    rs.getString("Image"),
                    rs.getDate("PostedDate"),
                    rs.getString("Author"),
                    rs.getInt("ViewCount"),
                    rs.getString("CategoryId"),
                    rs.getBoolean("Home")
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    // Lấy danh sách tin theo Loại (Category)
    public List<News> getNewsByCategory(String categoryId) {
        List<News> list = new ArrayList<>();
        String query = "SELECT * FROM News WHERE CategoryId = ? ORDER BY PostedDate DESC";
        try {
            conn = new Jdbc().getConnection();
            ps = conn.prepareStatement(query);
            ps.setString(1, categoryId);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new News(
                    rs.getString("Id"),
                    rs.getString("Title"),
                    rs.getString("Content"),
                    rs.getString("Image"),
                    rs.getDate("PostedDate"),
                    rs.getString("Author"),
                    rs.getInt("ViewCount"),
                    rs.getString("CategoryId"),
                    rs.getBoolean("Home")
                ));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    // Hàm phụ: Tăng view
    public void increaseViewCount(String id) {
        String query = "UPDATE News SET ViewCount = ViewCount + 1 WHERE Id = ?";
        try {
            conn = new Jdbc().getConnection();
            ps = conn.prepareStatement(query);
            ps.setString(1, id);
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    // Hàm phụ: Lấy 3 tin cùng loại (trừ tin đang xem) cho phần "Tin cùng loại" [cite: 135]
    public List<News> getRelatedNews(String categoryId, String currentNewsId) {
        List<News> list = new ArrayList<>();
        String query = "SELECT TOP 3 * FROM News WHERE CategoryId = ? AND Id != ? ORDER BY PostedDate DESC";
        try {
            conn = new Jdbc().getConnection();
            ps = conn.prepareStatement(query);
            ps.setString(1, categoryId);
            ps.setString(2, currentNewsId);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new News(
                     rs.getString("Id"), rs.getString("Title"), rs.getString("Content"),
                     rs.getString("Image"), rs.getDate("PostedDate"), rs.getString("Author"),
                     rs.getInt("ViewCount"), rs.getString("CategoryId"), rs.getBoolean("Home")
                ));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
    
 // 1. Lấy tất cả tin (Dùng cho Admin)
    public List<News> getAllNews() {
        List<News> list = new ArrayList<>();
        String query = "SELECT * FROM News ORDER BY PostedDate DESC";
        try {
            conn = new Jdbc().getConnection();
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new News(
                    rs.getString("Id"), rs.getString("Title"), rs.getString("Content"),
                    rs.getString("Image"), rs.getDate("PostedDate"), rs.getString("Author"),
                    rs.getInt("ViewCount"), rs.getString("CategoryId"), rs.getBoolean("Home")
                ));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    // 2. Lấy tin theo Tác giả (Dùng cho Phóng viên)
    public List<News> getNewsByAuthor(String authorId) {
        List<News> list = new ArrayList<>();
        String query = "SELECT * FROM News WHERE Author = ? ORDER BY PostedDate DESC";
        try {
            conn = new Jdbc().getConnection();
            ps = conn.prepareStatement(query);
            ps.setString(1, authorId);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new News(
                    rs.getString("Id"), rs.getString("Title"), rs.getString("Content"),
                    rs.getString("Image"), rs.getDate("PostedDate"), rs.getString("Author"),
                    rs.getInt("ViewCount"), rs.getString("CategoryId"), rs.getBoolean("Home")
                ));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    // 3. Xóa tin
    public void deleteNews(String id) {
        String query = "DELETE FROM News WHERE Id = ?";
        try {
            conn = new Jdbc().getConnection();
            ps = conn.prepareStatement(query);
            ps.setString(1, id);
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
 // 4. Thêm tin mới
 // Trong file NewsDAO.java

    public void insertNews(News n) {
        // Câu lệnh SQL PHẢI có cột Id
        String query = "INSERT INTO News (Id, Title, Content, Image, PostedDate, Author, CategoryId, Home, ViewCount) " +
                       "VALUES (?, ?, ?, ?, GETDATE(), ?, ?, ?, 0)";
        try {
            conn = new Jdbc().getConnection();
            ps = conn.prepareStatement(query);
            
            // Set tham số theo thứ tự
            ps.setString(1, n.getId()); // ID do người dùng nhập
            ps.setString(2, n.getTitle());
            ps.setString(3, n.getContent());
            ps.setString(4, n.getImage());
            ps.setString(5, n.getAuthorId());
            ps.setString(6, n.getCategoryId());
            ps.setBoolean(7, n.isHome());
            
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    // 5. Cập nhật tin
    public void updateNews(News n) {
        String query = "UPDATE News SET Title=?, Content=?, Image=?, CategoryId=?, Home=? WHERE Id=?";
        try {
            conn = new Jdbc().getConnection();
            ps = conn.prepareStatement(query);
            ps.setString(1, n.getTitle());
            ps.setString(2, n.getContent());
            ps.setString(3, n.getImage());
            ps.setString(4, n.getCategoryId());
            ps.setBoolean(5, n.isHome());
            ps.setString(6, n.getId());
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

 
    // Hàm tìm kiếm bài viết theo tiêu đề
    public List<News> searchByName(String txtSearch) {
        List<News> list = new ArrayList<>();
        // Lưu ý: Dùng N'...' nếu muốn tìm kiếm tiếng Việt có dấu trong SQL Server
        String query = "SELECT * FROM News WHERE Title LIKE ?"; 
        
        try {
            conn = new Jdbc().getConnection();
            ps = conn.prepareStatement(query);
            // Thêm N trước chuỗi để tìm kiếm Unicode tốt hơn (tùy chọn)
            ps.setString(1, "%" + txtSearch + "%");
            rs = ps.executeQuery();
            
            while (rs.next()) {
                list.add(new News(
                    rs.getString("Id"),           
                    rs.getString("Title"),      
                    rs.getString("Content"),     
                    rs.getString("Image"),       
                    rs.getDate("PostedDate"),    
                    rs.getString("Author"),      // <--- ĐÃ SỬA: AuthorId -> Author
                    rs.getInt("ViewCount"),      
                    rs.getString("CategoryId"),  
                    rs.getBoolean("Home")        
                ));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
    

	 // Hàm lấy Top 5 tin tức xem nhiều nhất
	 public List<News> getTopNews() {
	     List<News> list = new ArrayList<>();
	     // SQL Server dùng SELECT TOP
	     String query = "SELECT TOP 5 * FROM News ORDER BY ViewCount DESC";
	     try {
	         conn = new Jdbc().getConnection();
	         ps = conn.prepareStatement(query);
	         rs = ps.executeQuery();
	         while (rs.next()) {
	             list.add(new News(
	                 rs.getString("Id"),
	                 rs.getString("Title"),
	                 rs.getString("Content"),
	                 rs.getString("Image"),
	                 rs.getDate("PostedDate"),
	                 rs.getString("Author"), // Lưu ý: Cột này trong DB là Author hay AuthorId tùy lúc bạn sửa
	                 rs.getInt("ViewCount"),
	                 rs.getString("CategoryId"),
	                 rs.getBoolean("Home")
	             ));
	         }
	     } catch (Exception e) {
	         e.printStackTrace();
	     }
	     return list;
	 }
}