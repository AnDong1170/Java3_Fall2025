USE HRM;
GO

-- Stored Procedure: Thêm mới Department
IF OBJECT_ID('spInsert', 'P') IS NOT NULL
    DROP PROCEDURE spInsert;
GO

CREATE PROCEDURE spInsert(
    @Id CHAR(3),
    @Name NVARCHAR(50),
    @Description NVARCHAR(255)
) AS BEGIN
    INSERT INTO Departments(Id, Name, Description)
        VALUES(@Id, @Name, @Description)
END
GO

-- Stored Procedure: Cập nhật Department
IF OBJECT_ID('spUpdate', 'P') IS NOT NULL
    DROP PROCEDURE spUpdate;
GO

CREATE PROCEDURE spUpdate(
    @Id CHAR(3),
    @Name NVARCHAR(50),
    @Description NVARCHAR(255)
) AS BEGIN
    UPDATE Departments
        SET Name=@Name, Description=@Description
        WHERE Id=@Id
END
GO

-- Stored Procedure: Xóa Department theo Id
IF OBJECT_ID('spDeleteById', 'P') IS NOT NULL
    DROP PROCEDURE spDeleteById;
GO

CREATE PROCEDURE spDeleteById(
    @Id CHAR(3)
) AS BEGIN
    DELETE FROM Departments WHERE Id=@Id
END
GO

-- Stored Procedure: Truy vấn tất cả Departments
IF OBJECT_ID('spSelectAll', 'P') IS NOT NULL
    DROP PROCEDURE spSelectAll;
GO

CREATE PROCEDURE spSelectAll
AS
BEGIN
    SELECT * FROM Departments
END
GO

-- Stored Procedure: Truy vấn Department theo Id
IF OBJECT_ID('spSelectById', 'P') IS NOT NULL
    DROP PROCEDURE spSelectById;
GO

CREATE PROCEDURE spSelectById(
    @Id CHAR(3)
) AS BEGIN
    SELECT * FROM Departments WHERE Id=@Id
END
GO

