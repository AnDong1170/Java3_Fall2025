-- Tạo database HRM
IF NOT EXISTS (SELECT * FROM sys.databases WHERE name = 'HRM')
BEGIN
    CREATE DATABASE HRM;
END
GO

USE HRM;
GO

-- Tạo bảng Departments
IF OBJECT_ID('Departments', 'U') IS NOT NULL
    DROP TABLE Departments;
GO

CREATE TABLE Departments(
    Id CHAR(3) NOT NULL,
    Name NVARCHAR(50) NOT NULL,
    Description NVARCHAR(255) NULL,
    PRIMARY KEY(Id)
);
GO

-- Tạo bảng Employees
IF OBJECT_ID('Employees', 'U') IS NOT NULL
    DROP TABLE Employees;
GO

CREATE TABLE Employees(
    Id VARCHAR(20) NOT NULL,
    Password NVARCHAR(50) NOT NULL,
    Fullname NVARCHAR(50) NOT NULL,
    Photo NVARCHAR(50) NOT NULL,
    Gender BIT NOT NULL,
    Birthday DATE NOT NULL,
    Salary FLOAT NOT NULL,
    DepartmentId CHAR(3) NOT NULL,
    PRIMARY KEY(Id),
    FOREIGN KEY(DepartmentId) REFERENCES Departments(Id)
        ON DELETE CASCADE
        ON UPDATE CASCADE
);
GO

-- Insert dữ liệu mẫu cho Departments
INSERT INTO Departments(Id, Name, Description) VALUES
('IT', N'Công nghệ thông tin', N'Phòng ban phụ trách công nghệ thông tin'),
('HR', N'Nhân sự', N'Phòng ban quản lý nhân sự'),
('MK', N'Marketing', N'Phòng ban marketing và quảng cáo'),
('AC', N'Kế toán', N'Phòng ban kế toán tài chính');
GO

-- Insert dữ liệu mẫu cho Employees
INSERT INTO Employees(Id, Password, Fullname, Photo, Gender, Birthday, Salary, DepartmentId) VALUES
('NV001', '123456', N'Nguyễn Văn A', 'avatar1.jpg', 1, '1990-01-15', 15000000, 'IT'),
('NV002', '123456', N'Trần Thị B', 'avatar2.jpg', 0, '1992-05-20', 12000000, 'HR'),
('NV003', '123456', N'Lê Văn C', 'avatar3.jpg', 1, '1988-03-10', 18000000, 'MK');
GO

