package poly.dao;

import java.util.List;
import poly.entity.Department;

public interface DepartmentDAO {
    List<Department> findAll();
    Department findById(String id);
    void create(Department department);
    void update(Department department);
    void deleteById(String id);
}

