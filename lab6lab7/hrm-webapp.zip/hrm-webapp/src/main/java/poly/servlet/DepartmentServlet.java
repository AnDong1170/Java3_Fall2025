package poly.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.apache.commons.beanutils.BeanUtils;
import poly.dao.DepartmentDAO;
import poly.dao.DepartmentDAOImpl;
import poly.entity.Department;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.List;

@WebServlet({
    "/department/index",
    "/department/edit/*",
    "/department/create",
    "/department/update",
    "/department/delete",
    "/department/reset"
})
public class DepartmentServlet extends HttpServlet {
    
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        processRequest(req, resp);
    }
    
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        processRequest(req, resp);
    }
    
    private void processRequest(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try {
            Department form = new Department();
            
            // Only populate form if there are parameters (POST request with data)
            if (req.getParameterMap() != null && !req.getParameterMap().isEmpty()) {
                try {
                    BeanUtils.populate(form, req.getParameterMap());
                } catch (IllegalAccessException | InvocationTargetException e) {
                    System.err.println("Error populating form: " + e.getMessage());
                    e.printStackTrace();
                }
            }
            
            DepartmentDAO dao = new DepartmentDAOImpl();
            String path = req.getServletPath();
            
            if (path.contains("edit")) {
                String pathInfo = req.getPathInfo();
                if (pathInfo != null && pathInfo.length() > 1) {
                    String id = pathInfo.substring(1);
                    form = dao.findById(id);
                    if (form == null) {
                        form = new Department();
                    }
                }
            } else if (path.contains("create")) {
                try {
                    dao.create(form);
                } catch (Exception e) {
                    System.err.println("Error creating department: " + e.getMessage());
                    e.printStackTrace();
                }
                form = new Department();
            } else if (path.contains("update")) {
                try {
                    dao.update(form);
                } catch (Exception e) {
                    System.err.println("Error updating department: " + e.getMessage());
                    e.printStackTrace();
                }
            } else if (path.contains("delete")) {
                try {
                    dao.deleteById(form.getId());
                } catch (Exception e) {
                    System.err.println("Error deleting department: " + e.getMessage());
                    e.printStackTrace();
                }
                form = new Department();
            } else {
                form = new Department();
            }
            
            req.setAttribute("item", form);
            List<Department> list = dao.findAll();
            req.setAttribute("list", list);
            req.getRequestDispatcher("/views/department/index.jsp").forward(req, resp);
            
        } catch (Exception e) {
            System.err.println("Error in DepartmentServlet: " + e.getMessage());
            e.printStackTrace();
            resp.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "An error occurred: " + e.getMessage());
        }
    }
}

