package poly.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.beanutils.ConvertUtils;
import org.apache.commons.beanutils.converters.DateConverter;
import poly.dao.DepartmentDAO;
import poly.dao.DepartmentDAOImpl;
import poly.dao.EmployeeDAO;
import poly.dao.EmployeeDAOImpl;
import poly.entity.Department;
import poly.entity.Employee;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.Date;
import java.util.List;

@WebServlet({
    "/employee/index",
    "/employee/edit/*",
    "/employee/create",
    "/employee/update",
    "/employee/delete",
    "/employee/reset"
})
@MultipartConfig(
    maxFileSize = 5242880L,      // 5MB
    maxRequestSize = 5242880L    // 5MB
)
public class EmployeeServlet extends HttpServlet {
    private static final String UPLOAD_DIR = "uploads";
    private static final String DEFAULT_PHOTO = "no-photo.jpg";
    private static volatile boolean dateConverterRegistered = false;
    
    @Override
    public void init() throws ServletException {
        try {
            super.init();
            // Register date converter once during servlet initialization
            synchronized (EmployeeServlet.class) {
                if (!dateConverterRegistered) {
                    try {
                        DateConverter dateConverter = new DateConverter(null);
                        dateConverter.setPattern("yyyy-MM-dd");
                        ConvertUtils.register(dateConverter, Date.class);
                        dateConverterRegistered = true;
                    } catch (Exception e) {
                        System.err.println("Warning: Error registering date converter: " + e.getMessage());
                        e.printStackTrace();
                        // Don't throw exception, servlet can still work without date converter
                    }
                }
            }
        } catch (Exception e) {
            System.err.println("Error initializing EmployeeServlet: " + e.getMessage());
            e.printStackTrace();
            throw new ServletException("Failed to initialize EmployeeServlet", e);
        }
    }
    
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        processRequest(req, resp, false);
    }
    
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String contentType = req.getContentType();
        boolean isMultipart = contentType != null && contentType.toLowerCase().startsWith("multipart/form-data");
        processRequest(req, resp, isMultipart);
    }
    
    private void processRequest(HttpServletRequest req, HttpServletResponse resp, boolean isMultipart) throws ServletException, IOException {
        Employee form = new Employee();
        
        EmployeeDAO dao = new EmployeeDAOImpl();
        DepartmentDAO deptDao = new DepartmentDAOImpl();
        String path = req.getServletPath();
        
        if (path.contains("edit")) {
            String pathInfo = req.getPathInfo();
            if (pathInfo != null && pathInfo.length() > 1) {
                String id = pathInfo.substring(1);
                form = dao.findById(id);
            }
        } else {
            try {
                // Handle gender conversion
                String genderStr = req.getParameter("gender");
                if (genderStr != null) {
                    form.setGender("true".equals(genderStr));
                }
                
                BeanUtils.populate(form, req.getParameterMap());
                
                // Handle file upload only if request is multipart
                boolean photoSet = false;
                if (isMultipart) {
                    try {
                        Part photoPart = req.getPart("photoFile");
                        if (photoPart != null && photoPart.getSize() > 0) {
                            String fileName = photoPart.getSubmittedFileName();
                            if (fileName != null && !fileName.isEmpty() && !fileName.trim().isEmpty()) {
                                String uploadPath = getServletContext().getRealPath("") + File.separator + UPLOAD_DIR;
                                File uploadDir = new File(uploadPath);
                                if (!uploadDir.exists()) {
                                    uploadDir.mkdirs();
                                }
                                String filePath = uploadPath + File.separator + fileName;
                                photoPart.write(filePath);
                                form.setPhoto(fileName);
                                photoSet = true;
                            }
                        }
                    } catch (Exception e) {
                        // Ignore multipart parsing errors
                        System.err.println("Error processing multipart: " + e.getMessage());
                        e.printStackTrace();
                    }
                }
                
                // If no photo was uploaded, handle based on action
                if (!photoSet) {
                    if (path.contains("update")) {
                        // Keep existing photo if updating without new file
                        Employee existing = dao.findById(form.getId());
                        if (existing != null && existing.getPhoto() != null && !existing.getPhoto().trim().isEmpty()) {
                            form.setPhoto(existing.getPhoto());
                        } else {
                            form.setPhoto(DEFAULT_PHOTO);
                        }
                    } else {
                        // For create or other actions, set default photo
                        form.setPhoto(DEFAULT_PHOTO);
                    }
                }
                
                // Final check: Ensure photo is never null or empty before creating/updating
                if (form.getPhoto() == null || form.getPhoto().trim().isEmpty()) {
                    form.setPhoto(DEFAULT_PHOTO);
                }
            } catch (IllegalAccessException | InvocationTargetException e) {
                e.printStackTrace();
            }
            
            if (path.contains("create")) {
                dao.create(form);
                form = new Employee();
            } else if (path.contains("update")) {
                dao.update(form);
            } else if (path.contains("delete")) {
                dao.deleteById(form.getId());
                form = new Employee();
            } else {
                form = new Employee();
            }
        }
        
        req.setAttribute("item", form);
        List<Employee> list = dao.findAll();
        req.setAttribute("list", list);
        List<Department> departments = deptDao.findAll();
        req.setAttribute("departments", departments);
        req.getRequestDispatcher("/views/employee/index.jsp").forward(req, resp);
    }
}

