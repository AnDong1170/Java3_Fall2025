package lab4Servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/dangky")
public class Bai3 extends HttpServlet
{
	private static final long serialVersionUID = 1L;

    // GET -> Hiển thị form đăng ký
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
  
        req.getRequestDispatcher("/dangky.jsp").forward(req, resp);
    }

    // POST -> Xử lý dữ liệu form
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        req.setCharacterEncoding("UTF-8");

        // Đọc các tham số
        String fullname = req.getParameter("fullname");
        String password = req.getParameter("password");
        String gender = req.getParameter("gender");
        String married = req.getParameter("married");
        String country = req.getParameter("country");
        String[] hobbies = req.getParameterValues("hobbies");
        String note = req.getParameter("note");

        // Xuất ra console để kiểm tra
        System.out.println("Tên đăng nhập: " + fullname);
        System.out.println("Mật khẩu: " + password);
        System.out.println("Giới tính: " + gender);
        System.out.println("Đã có gia đình: " + (married != null ? "Có" : "Chưa"));
        System.out.println("Quốc gia: " + country);
        System.out.println("Sở thích:");
        if (hobbies != null) {
            for (String h : hobbies) {
                System.out.println(" - " + h);
            }
        } else {
            System.out.println("Không có sở thích nào được chọn.");
        }
        System.out.println("Ghi chú: " + note);

        // Gửi dữ liệu sang trang kết quả nếu cần
        req.setAttribute("fullname", fullname);
        req.setAttribute("gender", gender);
        req.setAttribute("married", married != null ? "Có" : "Chưa");
        req.setAttribute("country", country);
        req.setAttribute("hobbies", hobbies);
        req.setAttribute("note", note);

        req.getRequestDispatcher("/ketqua.jsp").forward(req, resp);
    }
	

}
