package lab4Servlet;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

@WebServlet("/upload")
@MultipartConfig(
        fileSizeThreshold = 1024 * 1024,   // 1MB
        maxFileSize = 1024 * 1024 * 10,    // 10MB
        maxRequestSize = 1024 * 1024 * 50  // 50MB
)
public class Bai4 extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        req.getRequestDispatcher("/upload.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        Part part = req.getPart("photo");

        if (part == null || part.getSize() == 0) {
            req.setAttribute("message", "Không có file được chọn!");
            req.getRequestDispatcher("/upload.jsp").forward(req, resp);
            return;
        }

        // Lấy tên file
        String fileName = part.getSubmittedFileName();

        // Thư mục static khi chạy Tomcat
        String relativePath = "/static/file";
        String absolutePath = req.getServletContext().getRealPath(relativePath);

        File dir = new File(absolutePath);
        if (!dir.exists()) {
            dir.mkdirs();
        }

        // Tạo tên file mới để tránh trùng
        String savedName = System.currentTimeMillis() + "_" + fileName;
        File savedFile = new File(dir, savedName);

        // Lưu file
        try (InputStream in = part.getInputStream();
             FileOutputStream out = new FileOutputStream(savedFile)) {

            byte[] buffer = new byte[1024];
            int length;
            while ((length = in.read(buffer)) > 0) {
                out.write(buffer, 0, length);
            }
        }

        // Đường dẫn hiển thị trên web
        String webPath = req.getContextPath() + relativePath + "/" + savedName;

        req.setAttribute("message", "Upload thành công!");
        req.setAttribute("imagePath", webPath);

        req.getRequestDispatcher("/upload.jsp").forward(req, resp);
    }
}
