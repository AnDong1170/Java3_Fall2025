package Controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/Tinh2so")
public class Bai5Controller extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
			req.getRequestDispatcher("/bai5.jsp").forward(req, resp);
	}
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		float a,b,kq;
		a=Float.parseFloat(req.getParameter("txta").toString());
		b=Float.parseFloat(req.getParameter("txtb").toString());
		kq=a+b;
		req.setAttribute("kq",kq);
		
		req.getRequestDispatcher("/bai5.jsp").forward(req, resp);
	}

}
