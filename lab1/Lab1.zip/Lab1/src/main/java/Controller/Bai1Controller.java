package Controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/bai1")
public class Bai1Controller extends HttpServlet {
@Override
protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException { //req gửi đi, resp phản hồi
	// TODO Auto-generated method stub
	req.getRequestDispatcher("bai1.jsp").forward(req, resp); // Chuyển hướng đến trang bài 1
}
}
