package Controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet({"/bai4","/crud/them","/crud/sua","/crud/xoa"}) //Đặt nhiều tên ({})
public class Bai4Controller extends HttpServlet {
@Override
protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	// TODO Auto-generated method stub
	String uri = req.getRequestURI();
	if (uri.contains("/crud/them"))  //contains: chứa đựng
		resp.getWriter().println("<h1> add</h1>");
	else if (uri.endsWith("/crud/sua")) //endsWith = contains
		resp.getWriter().println("<h1> update</h1>");
	else if (uri.contains("/crud/xoa")) 
		resp.getWriter().println("<h1> delete </h1>");
	else 
		resp.getWriter().println("<h1>i don't know </h1>");
	
}
}
																																																																																																																															